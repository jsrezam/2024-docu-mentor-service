import gradio as gr

def greet(name, intensity):
    return "Hello, " + name + "!" * int(intensity)

ui = gr.Interface(
    fn=greet,
    inputs=["text", "slider"],
    outputs=["text"],
)

ui.launch()
