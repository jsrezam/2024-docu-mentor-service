from fastapi import FastAPI
from pydantic import BaseModel
from query_data import query_rag
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()
app.add_middleware(
    CORSMiddleware, 
    allow_origins= ["*"], 
    allow_credentials=True,    
    allow_methods=["*"],  
    allow_headers=["*"],
)

class QueryRequest(BaseModel):
    text: str

@app.post("/chatbot")
def query(query: QueryRequest):
    response = query_rag(query.text)
    return {"Response": response}
